"""Thin entry script for PyInstaller.

PyInstaller works best when you point it to a .py file.
"""

from scorpio_pipe.ui.launcher_app import main


if __name__ == "__main__":
    main()
