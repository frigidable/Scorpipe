"""I/O helpers (FITS/JSON) for pipeline products."""
