"""Pipeline stages (calibration/reduction wrappers)."""
