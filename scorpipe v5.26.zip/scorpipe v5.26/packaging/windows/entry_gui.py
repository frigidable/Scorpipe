"""PyInstaller entry-point for the Scorpipe GUI."""

from scorpio_pipe.ui.launcher_app import main


if __name__ == "__main__":
    main()
