This folder is used for pipeline runs.

Recommended convention:
  work/<dd_mm_yyyy>/config.yaml

Each run directory is self-contained (config uses work_dir: ".") and will contain:
  raw/  calibs/  wavesol/  cosmics/  products/  qc/  (legacy: calib/, report/ ...)
